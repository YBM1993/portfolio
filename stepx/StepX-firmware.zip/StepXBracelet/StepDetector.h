#pragma once
#include <cmath>
#include <cstdint>

// A prototype gait detector, independent of Arduino for host-side tests.
// Input is acceleration magnitude in g, sampled about every 20 ms.
class StepDetector {
public:
    void reset() {
        initialized_ = false;
        samples_ = 0;
        streak_ = 0;
        armed_ = true;
    }

    uint8_t update(float magnitude, uint32_t now) {
        if (!std::isfinite(magnitude) || magnitude < 0.2f || magnitude > 6.0f) {
            reset();
            return 0;
        }
        if (!initialized_ || uint32_t(now - lastSample_) > 150) {
            smooth_ = baseline_ = magnitude;
            samples_ = 0;
            streak_ = 0;
            armed_ = true;
            initialized_ = true;
        }
        lastSample_ = now;
        smooth_ += 0.35f * (magnitude - smooth_);
        baseline_ += 0.02f * (smooth_ - baseline_);
        const float movement = smooth_ - baseline_;
        if (samples_ < 100) { ++samples_; return 0; } // settle for ~2 seconds
        if (movement < 0.025f) armed_ = true;
        if (!armed_ || movement < 0.12f) return 0;
        armed_ = false;
        const uint32_t elapsed = now - lastPeak_;
        if (streak_ > 0 && elapsed < 280) return 0;
        if (streak_ == 0 || elapsed > 1500) streak_ = 1;
        else if (streak_ < 4) ++streak_;
        lastPeak_ = now;
        // Confirm three consecutive peaks before including the first two.
        if (streak_ == 3) return 3;
        if (streak_ >= 4) return 1;
        return 0;
    }

private:
    bool initialized_ = false;
    bool armed_ = true;
    uint16_t samples_ = 0;
    uint8_t streak_ = 0;
    uint32_t lastSample_ = 0;
    uint32_t lastPeak_ = 0;
    float smooth_ = 1.0f;
    float baseline_ = 1.0f;
};
